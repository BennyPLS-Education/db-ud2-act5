create
    definer = root@`%` procedure get_department(IN id int, OUT num_employees int, OUT avg_salary int)
main: BEGIN
    IF NOT EXISTS (SELECT * FROM DEPT WHERE DEPT_NO = id) THEN
        SET num_employees = 0;
        SET avg_salary = -1;
        LEAVE main;
    END IF;

    SET num_employees = (SELECT (COUNT(*)) FROM DEPT WHERE DEPT_NO = id);

    IF num_employees = 0 THEN
        SET avg_salary = 0;
        LEAVE main;
    END IF;

    SET avg_salary = (SELECT AVG(SALARI)  FROM EMP WHERE DEPT_NO = id);
END;

